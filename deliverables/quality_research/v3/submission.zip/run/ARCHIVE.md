# Standalone archive

Directories: source (installable Python project), data (full prepared texture set),
run (adaptive weights, histories, reports, probes, actual output PNG/NPY),
user_quartet/inputs (selected original/conversion manifest).

From the extracted archive, run:

```bash
cd source
python -m pip install -r requirements.txt
python -m pip install -e .
python -m doe predict --checkpoint ../run/best.pt \
  --images ../user_quartet/inputs/plane_1.png ../user_quartet/inputs/plane_2.png \
           ../user_quartet/inputs/plane_3.png ../user_quartet/inputs/plane_4.png \
  --output NEW_OUTPUT --device cpu --threads 2
python scripts/compare_models.py --data ../data \
  --checkpoint baseline=../run/texture_parent.pt \
  --checkpoint adaptive=../run/best.pt --output NEW_BENCHMARK.json --threads 1
```

One common DOE. Quality goal 0.8 for both Pearson and SSIM has not been achieved.
run/result is the raw adaptive network; run/user_refined_3000 is a slower hybrid.
run/probes includes clearly marked independent-DOE controls and changed-camera-grid
research, not claims of compliance or quality gains on the original grid.
run/kaggle is a complete private job package; full GPU training has not been submitted.
Never put credentials in code, chat or Git.
